RecruitIQ - Internship Submission Package

Included files:
1. concept_note.md         - 1-page concept note describing problem, solution, timeline, tech stack.
2. mini_deck.html          - 3-slide mini-deck (open in browser).
3. README.txt              - This file.

How to use:
- Download and unzip the package.
- View the concept note (Markdown) with any editor or convert to PDF if required.
- Open mini_deck.html in a browser to view the slides.
