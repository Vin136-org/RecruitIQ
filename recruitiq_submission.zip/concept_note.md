# RecruitIQ — Smart, Self-Learning Recruitment Platform

## 1. Pain Points (2–3)
**1. Fragmented Candidate Sourcing & Tracking:**  
Recruiters juggle multiple platforms — LinkedIn, job portals, spreadsheets, and CRMs — to source, screen, and track candidates. This creates inefficiency, data loss, and duplication.

**2. Manual Screening & Bias in Selection:**  
Resume screening and shortlisting are repetitive and subjective tasks. Recruiters spend hours filtering unqualified profiles manually, leading to inconsistency and slower turnaround.

**3. Inefficient Communication & Onboarding:**  
Candidate updates, interview scheduling, and onboarding follow-ups rely heavily on emails or third-party tools (Calendly, Slack, etc.), causing delays and lack of visibility.

## 2. Proposed Solution — RecruitIQ
**What it is:** An AI-driven unified recruitment hub that automates sourcing, screening, and onboarding with minimal third-party dependencies.

**Core Features:**
- Smart Candidate Parser (in-house NLP)
- AI-Powered Candidate Ranking Engine (proprietary scoring)
- Unified Talent Pool Database (centralized search)
- Auto-Scheduler & Chat Assistant (in-built)
- Recruiter Dashboard & Analytics (real-time insights)

**How it solves problems:**
- Centralizes candidate data to eliminate fragmentation.
- Automates resume parsing and ranking to reduce manual screening time by ~60%.
- Integrates scheduling and messaging to improve candidate engagement and reduce tool-switching.

**How it reduces external tool dependency:**
- Uses open-source NLP (e.g., spaCy) and in-house modules instead of paid parsing and sourcing APIs.
- Built-in scheduler and chat reduce need for Calendly/Slack/third-party bots.
- Modular design enables integrating only essential external services (email/host) if needed.

## 3. Timeline (2–4 Weeks)
**Week 1 — Discovery & Architecture:** Define workflows, DB schema, choose NLP models, build wireframes.  
**Week 2 — Development Sprint:** Implement resume parser, ranking engine, and basic dashboard UI.  
**Week 3 — Integration & Launch:** Add chat/scheduler, analytics, QA, and deploy MVP.

## 4. Tech Stack (minimal dependency)
- Frontend: React + Tailwind  
- Backend: Node.js / Express  
- DB: PostgreSQL  
- AI: Python (spaCy, scikit-learn)  
- Deployment: Docker + AWS EC2 (or internal server)

## 5. Outcome & Metrics
- Hire 2× faster
- Reduce manual screening by 60%
- Reduce third-party tool dependency by ~70%
- Transparent hiring pipeline with predictive analytics
